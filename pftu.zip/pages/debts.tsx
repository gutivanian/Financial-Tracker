import React, { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import Modal from '@/components/Modal';
import { Plus, AlertCircle, DollarSign, Calendar, Edit2, Trash2 } from 'lucide-react';
import { formatCurrency, formatDate } from '@/lib/utils';
import { apiGet, apiPost, apiPut, apiDelete } from '@/lib/api';

export default function Debts() {
  const [debts, setDebts] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [editingDebt, setEditingDebt] = useState<any>(null);
  const [selectedDebt, setSelectedDebt] = useState<any>(null);
  const [formData, setFormData] = useState({
    creditor_name: '',
    debt_type: 'personal',
    principal_amount: '',
    interest_rate: '',
    current_balance: '',
    minimum_payment: '',
    due_date: '',
    start_date: new Date().toISOString().split('T')[0],
    notes: ''
  });
  const [paymentData, setPaymentData] = useState({
    amount: '',
    payment_date: new Date().toISOString().split('T')[0],
    notes: ''
  });

  useEffect(() => {
    fetchDebts();
  }, []);

  const fetchDebts = async () => {
    try {
      setLoading(true);
      const data = await apiGet('/api/debts');
      setDebts(data.debts);
      setSummary(data.summary);
    } catch (error) {
      console.error('Error fetching debts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (debt?: any) => {
    if (debt) {
      setEditingDebt(debt);
      setFormData({
        creditor_name: debt.creditor_name,
        debt_type: debt.debt_type,
        principal_amount: debt.principal_amount,
        interest_rate: debt.interest_rate,
        current_balance: debt.current_balance,
        minimum_payment: debt.minimum_payment,
        due_date: debt.due_date,
        start_date: debt.start_date.split('T')[0],
        notes: debt.notes || ''
      });
    } else {
      setEditingDebt(null);
      setFormData({
        creditor_name: '',
        debt_type: 'personal',
        principal_amount: '',
        interest_rate: '',
        current_balance: '',
        minimum_payment: '',
        due_date: '',
        start_date: new Date().toISOString().split('T')[0],
        notes: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingDebt(null);
  };

  const handleOpenPaymentModal = (debt: any) => {
    setSelectedDebt(debt);
    setPaymentData({
      amount: debt.minimum_payment || '',
      payment_date: new Date().toISOString().split('T')[0],
      notes: ''
    });
    setIsPaymentModalOpen(true);
  };

  const handleClosePaymentModal = () => {
    setIsPaymentModalOpen(false);
    setSelectedDebt(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editingDebt 
        ? `/api/debts?id=${editingDebt.id}` 
        : '/api/debts';
      const method = editingDebt ? 'PUT' : 'POST';

      const response = editingAccount ? await apiPut(url, formData) : await apiPost(url, formData);

      if (response) {
        await fetchDebts();
        handleCloseModal();
      } else {
        alert('Failed to save debt');
      }
    } catch (error) {
      console.error('Error saving debt:', error);
      alert('Error saving debt');
    }
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDebt) return;

    try {
      // This would need a payment endpoint in your API
      const response = await fetch('/api/debts/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          debt_id: selectedDebt.id,
          ...paymentData
        })
      });

      if (response) {
        await fetchDebts();
        handleClosePaymentModal();
      } else {
        alert('Failed to record payment');
      }
    } catch (error) {
      console.error('Error recording payment:', error);
      alert('Error recording payment');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this debt?')) return;
    
    try {
      const response = await apiDelete(`/api/debts?id=${id}`);

      if (response) {
        await fetchDebts();
      } else {
        alert('Failed to delete debt');
      }
    } catch (error) {
      console.error('Error deleting debt:', error);
      alert('Error deleting debt');
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Debt Management</h1>
            <p className="text-dark-400 mt-1">Track dan manage semua hutang kamu</p>
          </div>
          <button onClick={() => handleOpenModal()} className="btn btn-primary flex items-center space-x-2">
            <Plus className="w-5 h-5" />
            <span>Add Debt</span>
          </button>
        </div>

        {summary && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="card bg-gradient-to-br from-danger/20 to-danger/5 border-danger/30">
              <p className="text-sm text-dark-400 mb-1">Total Debt</p>
              <h3 className="text-2xl font-bold text-danger">
                {formatCurrency(summary.total_debt)}
              </h3>
            </div>

            <div className="card bg-gradient-to-br from-warning/20 to-warning/5 border-warning/30">
              <p className="text-sm text-dark-400 mb-1">Monthly Payments</p>
              <h3 className="text-2xl font-bold text-warning">
                {formatCurrency(summary.monthly_payments)}
              </h3>
            </div>

            <div className="card bg-gradient-to-br from-info/20 to-info/5 border-info/30">
              <p className="text-sm text-dark-400 mb-1">Total Interest</p>
              <h3 className="text-2xl font-bold text-info">
                {formatCurrency(summary.total_interest)}
              </h3>
            </div>

            <div className="card bg-gradient-to-br from-success/20 to-success/5 border-success/30">
              <p className="text-sm text-dark-400 mb-1">Paid Off</p>
              <h3 className="text-2xl font-bold text-success">
                {summary.paid_off_count}
              </h3>
            </div>
          </div>
        )}

        <div className="card">
          <h2 className="text-xl font-bold text-white mb-6">Active Debts</h2>
          {loading ? (
            <div className="text-center py-12">
              <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-dark-400">Loading debts...</p>
            </div>
          ) : debts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-dark-400 mb-4">No debts recorded</p>
              <button onClick={() => handleOpenModal()} className="btn btn-primary">
                Add Debt
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {debts.map((debt) => {
                const progressPercentage = ((parseFloat(debt.principal_amount) - parseFloat(debt.current_balance)) / parseFloat(debt.principal_amount)) * 100;
                
                return (
                  <div key={debt.id} className="p-5 bg-dark-800 rounded-lg hover:bg-dark-750 transition-colors border-l-4 border-danger">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-danger/20 rounded-lg flex items-center justify-center">
                            <AlertCircle className="w-6 h-6 text-danger" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white">{debt.creditor_name}</h3>
                            <p className="text-sm text-dark-400 capitalize">{debt.debt_type.replace('_', ' ')}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-6">
                        <div className="text-right">
                          <p className="text-sm text-dark-400">Current Balance</p>
                          <p className="text-xl font-bold text-danger">{formatCurrency(debt.current_balance)}</p>
                          <p className="text-xs text-dark-400">of {formatCurrency(debt.principal_amount)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-dark-400">Monthly Payment</p>
                          <p className="font-semibold text-white">{formatCurrency(debt.minimum_payment)}</p>
                          <p className="text-xs text-dark-400">Interest: {debt.interest_rate}%</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleOpenPaymentModal(debt)}
                            className="btn btn-success btn-sm"
                          >
                            Pay
                          </button>
                          <button
                            onClick={() => handleOpenModal(debt)}
                            className="p-2 hover:bg-dark-700 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4 text-dark-400 hover:text-primary-400" />
                          </button>
                          <button
                            onClick={() => handleDelete(debt.id)}
                            className="p-2 hover:bg-dark-700 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4 text-dark-400 hover:text-danger" />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-dark-400">Paid Off Progress</span>
                        <span className="font-semibold text-white">{progressPercentage.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-dark-700 rounded-full h-2">
                        <div
                          className="h-2 bg-success rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(progressPercentage, 100)}%` }}
                        ></div>
                      </div>
                      <div className="flex items-center justify-between text-xs text-dark-400">
                        <span>Due Date: {debt.due_date}</span>
                        <span>Started: {formatDate(debt.start_date)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <Modal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          title={editingDebt ? 'Edit Debt' : 'Add New Debt'}
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Creditor Name</label>
              <input
                type="text"
                value={formData.creditor_name}
                onChange={(e) => setFormData({ ...formData, creditor_name: e.target.value })}
                className="input w-full"
                placeholder="e.g., Bank ABC"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Debt Type</label>
              <select
                value={formData.debt_type}
                onChange={(e) => setFormData({ ...formData, debt_type: e.target.value })}
                className="input w-full"
                required
              >
                <option value="personal">Personal Loan</option>
                <option value="credit_card">Credit Card</option>
                <option value="mortgage">Mortgage</option>
                <option value="auto">Auto Loan</option>
                <option value="student">Student Loan</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Principal Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.principal_amount}
                  onChange={(e) => setFormData({ ...formData, principal_amount: e.target.value })}
                  className="input w-full"
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Current Balance</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.current_balance}
                  onChange={(e) => setFormData({ ...formData, current_balance: e.target.value })}
                  className="input w-full"
                  placeholder="0.00"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Interest Rate (%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.interest_rate}
                  onChange={(e) => setFormData({ ...formData, interest_rate: e.target.value })}
                  className="input w-full"
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Minimum Payment</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.minimum_payment}
                  onChange={(e) => setFormData({ ...formData, minimum_payment: e.target.value })}
                  className="input w-full"
                  placeholder="0.00"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Start Date</label>
                <input
                  type="date"
                  value={formData.start_date}
                  onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                  className="input w-full"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Due Date (Each Month)</label>
                <input
                  type="text"
                  value={formData.due_date}
                  onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  className="input w-full"
                  placeholder="e.g., 15th"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Notes (Optional)</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="input w-full"
                rows={3}
                placeholder="Additional notes..."
              />
            </div>

            <div className="flex items-center space-x-3 pt-4">
              <button type="submit" className="btn btn-primary flex-1">
                {editingDebt ? 'Update Debt' : 'Add Debt'}
              </button>
              <button type="button" onClick={handleCloseModal} className="btn btn-secondary flex-1">
                Cancel
              </button>
            </div>
          </form>
        </Modal>

        <Modal
          isOpen={isPaymentModalOpen}
          onClose={handleClosePaymentModal}
          title={`Record Payment - ${selectedDebt?.creditor_name || ''}`}
          maxWidth="max-w-md"
        >
          <form onSubmit={handlePaymentSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Payment Amount</label>
              <input
                type="number"
                step="0.01"
                value={paymentData.amount}
                onChange={(e) => setPaymentData({ ...paymentData, amount: e.target.value })}
                className="input w-full"
                placeholder="0.00"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Payment Date</label>
              <input
                type="date"
                value={paymentData.payment_date}
                onChange={(e) => setPaymentData({ ...paymentData, payment_date: e.target.value })}
                className="input w-full"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Notes (Optional)</label>
              <textarea
                value={paymentData.notes}
                onChange={(e) => setPaymentData({ ...paymentData, notes: e.target.value })}
                className="input w-full"
                rows={2}
                placeholder="Additional notes..."
              />
            </div>

            <div className="flex items-center space-x-3 pt-4">
              <button type="submit" className="btn btn-primary flex-1">
                Record Payment
              </button>
              <button type="button" onClick={handleClosePaymentModal} className="btn btn-secondary flex-1">
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      </div>
    </Layout>
  );
}