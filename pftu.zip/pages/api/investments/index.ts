import { NextApiResponse } from 'next';
import { authMiddleware, AuthRequest } from '@/lib/middleware/auth';
import { query as dbQuery } from '@/lib/db';

async function handler(
  req: AuthRequest,
  res: NextApiResponse
) {
  const userId = req.user?.userId;

  try {
    if (req.method === 'GET') {
      const query = `
        SELECT 
          *,
          (purchase_price * quantity) as total_cost,
          (current_price * quantity) as current_value,
          ((current_price * quantity) - (purchase_price * quantity)) as gain_loss,
          CASE 
            WHEN purchase_price > 0 THEN
              (((current_price - purchase_price) / purchase_price) * 100)
            ELSE 0
          END as gain_loss_percentage
        FROM investments
        WHERE user_id = $1
        ORDER BY asset_type, name
      `;

      const result = await dbQuery(query, [userId]);

      // Calculate portfolio summary
      const summary = {
        total_invested: 0,
        current_value: 0,
        total_gain_loss: 0,
        total_gain_loss_percentage: 0,
        by_asset_type: {} as Record<string, any>,
      };

      result.rows.forEach((inv: any) => {
        const totalCost = parseFloat(inv.total_cost) || 0;
        const currentValue = parseFloat(inv.current_value) || 0;
        const gainLoss = parseFloat(inv.gain_loss) || 0;

        summary.total_invested += totalCost;
        summary.current_value += currentValue;
        summary.total_gain_loss += gainLoss;

        // Group by asset type
        if (!summary.by_asset_type[inv.asset_type]) {
          summary.by_asset_type[inv.asset_type] = {
            total_invested: 0,
            current_value: 0,
            gain_loss: 0,
            count: 0,
          };
        }
        summary.by_asset_type[inv.asset_type].total_invested += totalCost;
        summary.by_asset_type[inv.asset_type].current_value += currentValue;
        summary.by_asset_type[inv.asset_type].gain_loss += gainLoss;
        summary.by_asset_type[inv.asset_type].count += 1;
      });

      if (summary.total_invested > 0) {
        summary.total_gain_loss_percentage = 
          (summary.total_gain_loss / summary.total_invested) * 100;
      }

      res.status(200).json({
        investments: result.rows,
        summary,
      });

    } else if (req.method === 'POST') {
      const {
        asset_type,
        name,
        ticker,
        purchase_date,
        purchase_price,
        quantity,
        current_price,
        platform,
        notes,
      } = req.body;

      if (!asset_type || !name || !purchase_date || !purchase_price || !quantity) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      const query = `
        INSERT INTO investments (
          user_id, asset_type, name, ticker, purchase_date,
          purchase_price, quantity, current_price, platform, notes
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        RETURNING *
      `;

      const result = await dbQuery(query, [
        userId,
        asset_type,
        name,
        ticker || null,
        purchase_date,
        purchase_price,
        quantity,
        current_price || purchase_price,
        platform || null,
        notes || null,
      ]);

      res.status(201).json(result.rows[0]);

    } else if (req.method === 'PUT') {
      const { id } = req.query;
      const {
        name,
        ticker,
        purchase_price,
        quantity,
        current_price,
        platform,
        notes,
      } = req.body;

      const query = `
        UPDATE investments SET
          name = COALESCE($1, name),
          ticker = COALESCE($2, ticker),
          purchase_price = COALESCE($3, purchase_price),
          quantity = COALESCE($4, quantity),
          current_price = COALESCE($5, current_price),
          platform = COALESCE($6, platform),
          notes = COALESCE($7, notes),
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $8 AND user_id = $9
        RETURNING *
      `;

      const result = await dbQuery(query, [
        name,
        ticker,
        purchase_price,
        quantity,
        current_price,
        platform,
        notes,
        id,
        userId,
      ]);

      if (result.rows.length === 0) {
        return res.status(404).json({ message: 'Investment not found' });
      }

      res.status(200).json(result.rows[0]);

    } else if (req.method === 'DELETE') {
      const { id } = req.query;

      await dbQuery(
        'DELETE FROM investments WHERE id = $1 AND user_id = $2',
        [id, userId]
      );

      res.status(200).json({ message: 'Investment deleted' });

    } else {
      res.status(405).json({ message: 'Method not allowed' });
    }
  } catch (error) {
    console.error('Investments API error:', error);
    res.status(500).json({ message: 'Internal server error', error: String(error) });
  }
}

export default authMiddleware(handler);
