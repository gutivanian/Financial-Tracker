import React, { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import Modal from '@/components/Modal';
import { Plus, TrendingUp, TrendingDown, Edit2, Trash2 } from 'lucide-react';
import { formatCurrency, formatPercentage } from '@/lib/utils';
import { apiGet, apiPost, apiPut, apiDelete } from '@/lib/api';

export default function Investments() {
  const [investments, setInvestments] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInvestment, setEditingInvestment] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    asset_type: 'stocks',
    quantity: '',
    purchase_price: '',
    current_price: '',
    purchase_date: new Date().toISOString().split('T')[0],
    notes: ''
  });

  useEffect(() => {
    fetchInvestments();
  }, []);

  const fetchInvestments = async () => {
    try {
      setLoading(true);
      const data = await apiGet('/api/investments');
      setInvestments(data.investments);
      setSummary(data.summary);
    } catch (error) {
      console.error('Error fetching investments:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (investment?: any) => {
    if (investment) {
      setEditingInvestment(investment);
      setFormData({
        name: investment.name,
        asset_type: investment.asset_type,
        quantity: investment.quantity,
        purchase_price: investment.purchase_price,
        current_price: investment.current_price,
        purchase_date: investment.purchase_date.split('T')[0],
        notes: investment.notes || ''
      });
    } else {
      setEditingInvestment(null);
      setFormData({
        name: '',
        asset_type: 'stocks',
        quantity: '',
        purchase_price: '',
        current_price: '',
        purchase_date: new Date().toISOString().split('T')[0],
        notes: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingInvestment(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editingInvestment 
        ? `/api/investments?id=${editingInvestment.id}` 
        : '/api/investments';
      const method = editingInvestment ? 'PUT' : 'POST';

      const response = editingAccount ? await apiPut(url, formData) : await apiPost(url, formData);

      if (response) {
        await fetchInvestments();
        handleCloseModal();
      } else {
        alert('Failed to save investment');
      }
    } catch (error) {
      console.error('Error saving investment:', error);
      alert('Error saving investment');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this investment?')) return;
    
    try {
      const response = await apiDelete(`/api/investments?id=${id}`);

      if (response) {
        await fetchInvestments();
      } else {
        alert('Failed to delete investment');
      }
    } catch (error) {
      console.error('Error deleting investment:', error);
      alert('Error deleting investment');
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Investment Portfolio</h1>
            <p className="text-dark-400 mt-1">Track semua investasi dan aset kamu</p>
          </div>
          <button onClick={() => handleOpenModal()} className="btn btn-primary flex items-center space-x-2">
            <Plus className="w-5 h-5" />
            <span>Add Investment</span>
          </button>
        </div>

        {summary && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="card bg-gradient-to-br from-primary-600/20 to-primary-700/5 border-primary-600/30">
              <p className="text-sm text-dark-400 mb-1">Total Invested</p>
              <h3 className="text-2xl font-bold text-white">
                {formatCurrency(summary.total_invested)}
              </h3>
            </div>

            <div className="card bg-gradient-to-br from-info/20 to-info/5 border-info/30">
              <p className="text-sm text-dark-400 mb-1">Current Value</p>
              <h3 className="text-2xl font-bold text-white">
                {formatCurrency(summary.current_value)}
              </h3>
            </div>

            <div className={`card bg-gradient-to-br ${
              summary.total_gain_loss >= 0
                ? 'from-success/20 to-success/5 border-success/30'
                : 'from-danger/20 to-danger/5 border-danger/30'
            }`}>
              <p className="text-sm text-dark-400 mb-1">Total Gain/Loss</p>
              <h3 className={`text-2xl font-bold ${
                summary.total_gain_loss >= 0 ? 'text-success' : 'text-danger'
              }`}>
                {summary.total_gain_loss >= 0 ? '+' : ''}
                {formatCurrency(summary.total_gain_loss)}
              </h3>
            </div>

            <div className="card bg-gradient-to-br from-warning/20 to-warning/5 border-warning/30">
              <p className="text-sm text-dark-400 mb-1">ROI</p>
              <h3 className={`text-2xl font-bold ${
                summary.total_gain_loss_percentage >= 0 ? 'text-success' : 'text-danger'
              }`}>
                {formatPercentage(summary.total_gain_loss_percentage, 2)}
              </h3>
            </div>
          </div>
        )}

        <div className="card">
          <h2 className="text-xl font-bold text-white mb-6">All Investments</h2>
          {loading ? (
            <div className="text-center py-12">
              <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-dark-400">Loading investments...</p>
            </div>
          ) : investments.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-dark-400 mb-4">No investments yet</p>
              <button onClick={() => handleOpenModal()} className="btn btn-primary">
                Add Your First Investment
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {investments.map((inv) => {
                const gainLoss = parseFloat(inv.gain_loss);
                const gainLossPercentage = parseFloat(inv.gain_loss_percentage);
                
                return (
                  <div key={inv.id} className="p-4 bg-dark-800 rounded-lg hover:bg-dark-750 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-primary-600/20 rounded-lg flex items-center justify-center">
                            <TrendingUp className="w-6 h-6 text-primary-400" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white">{inv.name}</h3>
                            <p className="text-sm text-dark-400 capitalize">{inv.asset_type.replace('_', ' ')}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-6">
                        <div className="text-right">
                          <p className="text-sm text-dark-400">Quantity</p>
                          <p className="font-semibold text-white">{inv.quantity}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-dark-400">Current Value</p>
                          <p className="font-semibold text-white">{formatCurrency(inv.current_value)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-dark-400">Gain/Loss</p>
                          <p className={`font-semibold ${gainLoss >= 0 ? 'text-success' : 'text-danger'}`}>
                            {gainLoss >= 0 ? '+' : ''}{formatCurrency(gainLoss)}
                          </p>
                          <p className={`text-xs ${gainLoss >= 0 ? 'text-success' : 'text-danger'}`}>
                            {gainLoss >= 0 ? '+' : ''}{formatPercentage(gainLossPercentage, 2)}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleOpenModal(inv)}
                            className="p-2 hover:bg-dark-700 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4 text-dark-400 hover:text-primary-400" />
                          </button>
                          <button
                            onClick={() => handleDelete(inv.id)}
                            className="p-2 hover:bg-dark-700 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4 text-dark-400 hover:text-danger" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <Modal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          title={editingInvestment ? 'Edit Investment' : 'Add New Investment'}
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Investment Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="input w-full"
                placeholder="e.g., Apple Stock"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Asset Type</label>
              <select
                value={formData.asset_type}
                onChange={(e) => setFormData({ ...formData, asset_type: e.target.value })}
                className="input w-full"
                required
              >
                <option value="stocks">Stocks</option>
                <option value="crypto">Cryptocurrency</option>
                <option value="mutual_funds">Mutual Funds</option>
                <option value="bonds">Bonds</option>
                <option value="real_estate">Real Estate</option>
                <option value="commodities">Commodities</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Quantity</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  className="input w-full"
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Purchase Date</label>
                <input
                  type="date"
                  value={formData.purchase_date}
                  onChange={(e) => setFormData({ ...formData, purchase_date: e.target.value })}
                  className="input w-full"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Purchase Price</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.purchase_price}
                  onChange={(e) => setFormData({ ...formData, purchase_price: e.target.value })}
                  className="input w-full"
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-400 mb-2">Current Price</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.current_price}
                  onChange={(e) => setFormData({ ...formData, current_price: e.target.value })}
                  className="input w-full"
                  placeholder="0.00"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-400 mb-2">Notes (Optional)</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="input w-full"
                rows={3}
                placeholder="Additional notes..."
              />
            </div>

            <div className="flex items-center space-x-3 pt-4">
              <button type="submit" className="btn btn-primary flex-1">
                {editingInvestment ? 'Update Investment' : 'Add Investment'}
              </button>
              <button type="button" onClick={handleCloseModal} className="btn btn-secondary flex-1">
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      </div>
    </Layout>
  );
}